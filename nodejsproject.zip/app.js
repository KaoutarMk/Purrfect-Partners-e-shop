const express = require('express');
const app = express();
const fs = require('fs');
const path = require('path');
const session = require('express-session');
const bodyParser = require('body-parser');
const port = 5432;

// Set the view engine to EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'Exercise4', 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'Exercise4', 'public'), { setHeaders: (res, path, stat) => {
    if (path.endsWith('.js')) {
        res.set('Content-Type', 'text/javascript');
    }
}}));

// Middleware to enable sessions
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true
}));

// Define routes

app.get('/', (req, res) => {
    // Determine the user's login status
    const loggedInStatus = req.session.user ? true : false;
    // Render the layout template for the home page
    res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'HomePage.html', loggedInStatus: loggedInStatus });
});

app.get('/HomePage.html', (req, res) => {
    res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'HomePage.html' });
});

app.get('/CreateAccount.html', (req, res) => {
    res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'CreateAccount.html' });
});

app.get('/login.html', (req, res) => {
    res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'login.html' });
});

app.get('/BrowseAvailablePets.html', (req, res) => {
    res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'BrowseAvailablePets.html' });
});

app.get('/FindDogCat.html', (req, res) => {
    res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'FindDogCat.html' });
});

app.get('/CatCare.html', (req, res) => {
    res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'CatCare.html' });
});

app.get('/ContactUs.html', (req, res) => {
    res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'ContactUs.html' });
});

app.get('/DogCare.html', (req, res) => {
    res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'DogCare.html' });
});

app.get('/HaveaPet.html', (req, res) => {
    // Determine the user's login status
    const loggedInStatus = req.session.user ? true : false;

    if (!loggedInStatus) {
        // If not logged in, redirect to login page
        res.redirect('/login.html');
    } else {
        // If logged in, render the HaveaPet.html page
        res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'HaveaPet.html' });
    }
});

app.get('/MainPage.html', (req, res) => {
    res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'MainPage.html' });
});

app.get('/PrivacyStatement.html', (req, res) => {
    res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'PrivacyStatement.html' });
});

app.get('/LogOut.html', (req, res) => {
    res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'LogOut.html' });
});

// Endpoint to check user login status
app.get('/loginStatus', (req, res) => {
    // Determine the user's login status
    const loggedInStatus = req.session.user ? true : false;
    // Send the login status as JSON response
    res.json({ loggedInStatus: loggedInStatus });
});

// Endpoint to handle account creation
app.post('/createAccount', (req, res) => {
    const username = req.body.username.trim();
    const password = req.body.password.trim();

    // Regular expressions for username and password validation
    const usernameRegex = /^[a-zA-Z0-9]+$/;
    const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d).{4,}$/;

    // Check if username and password meet the required format
    if (!usernameRegex.test(username)) {
        res.status(400).send('Username can contain letters (both upper/lower case) and digits only.');
        return;
    }
    if (!passwordRegex.test(password)) {
        res.status(400).send('Password must be at least 4 characters long, containing at least one letter and one digit.');
        return;
    }

    // Read the existing accounts from LoginFile.txt
    fs.readFile(path.join(__dirname, 'LoginFile.txt'), 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading login file:', err);
            res.status(500).send('Error reading login file');
            return;
        }

        // Check if the username already exists
        const lines = data.split('\n');
        for (const line of lines) {
            const storedUsername = line.split(':')[0];
            if (storedUsername === username) {
                res.status(400).send('Username is already taken');
                return;
            }
        }

        // Append the new account to the file
        const newUserInfo = `${username}:${password}\n`;
        fs.appendFile(path.join(__dirname, 'LoginFile.txt'), newUserInfo, (err) => {
            if (err) {
                console.error('Error appending to loginFile.txt:', err);
                res.status(500).send('Failed to create account. Please try again later.');
                return;
            }
            res.status(200).send('Account created successfully. You are now ready to login.');
        });
    });
});

// Function to validate login credentials
function validateLogin(username, password) {
    return new Promise((resolve, reject) => {
        const loginFilePath = path.join(__dirname, 'LoginFile.txt');

        // Read the contents of LoginFile.txt
        fs.readFile(loginFilePath, 'utf8', (err, data) => {
            if (err) {
                reject('Error reading login file');
            } else {
                // Split data into lines and check each line for a matching username and password pair
                const lines = data.trim().split('\n');
                for (const line of lines) {
                    const [storedUsername, storedPassword] = line.trim().split(':');
                    if (storedUsername === username && storedPassword === password) {
                        resolve('Login successful');
                        return;
                    }
                }
                // No matching pair found
                reject('Invalid username or password');
            }
        });
    });
}

// Endpoint to handle user login
app.post('/login', (req, res) => {
    const username = req.body.username.trim();
    const password = req.body.password.trim();

    // Validate login credentials
    validateLogin(username, password)
        .then(message => {
            req.session.user = { username: username}; // Storing user data in the session
            res.status(200).send(message);
        })
        .catch(error => {
            res.status(400).send(error);
        });
});

// Endpoint for logging out
app.post('/logout', (req, res) => {
    // Check if the user is logged in
    if (!req.session.user) {
        return res.status(400).send('You are not logged in');
    }

    // Destroy the session
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).send('Failed to log out');
        }
        
        // Clear the session cookie on the client-side
        res.clearCookie('sessionID');
        
        res.status(200).send('Logged out successfully');  
    });
});


// Endpoint to handle pet submission
app.post('/submitPet', (req, res) => {
    // Read form data as JSON
    const petInfo = req.body;

    // Extract necessary information
    const { animal, breed, age, gender, compatibility_dogs, compatibility_cats, compatibility_children, comments, owner_name, owner_email } = petInfo;

    // Read the availablePetFile.txt to determine the current counter
    fs.readFile(path.join(__dirname, 'availablePetFile.txt'), 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading availablePetFile.txt:', err);
            res.status(500).send('Failed to add pet information. Please try again later.');
        } else {
            // Parse pet entries from data
            const petEntries = data.trim().split('\n');

            let maxIndex = 0;
            for (const entry of petEntries) {
                const index = parseInt(entry.split(':')[0]);
                if (index > maxIndex) {
                    maxIndex = index;
                }
            }

            // Determine the next unique ID (counter)
            const counter = maxIndex + 1;

            // Construct the pet data entry
            const petData = `${counter}:${owner_name}:${animal}:${breed}:${age}:${gender}:${compatibility_dogs}:${compatibility_cats}:${compatibility_children}:${comments}:${owner_email}`;

            // Append the pet record to the availablePetFile.txt
            fs.appendFile(path.join(__dirname, 'availablePetFile.txt'), petData + '\n', (err) => {
                if (err) {
                    console.error('Error appending pet record:', err);
                    res.status(500).send('Failed to add pet information. Please try again later.');
                } else {
                    res.redirect('/HaveaPet.html'); // Redirect to the same page
                }
            });
        }
    });
});

app.post('/findPets', (req, res) => {
    // Retrieve form data from the request body
    const { animal1, breed1, age1, gender1, other_dogs, other_cats, small_children } = req.body;

    // Read pet information from the file
    const petInfoFilePath = path.join(__dirname, 'availablePetFile.txt');
    fs.readFile(petInfoFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading availablePetFile.txt:', err);
            return res.status(500).send('Failed to read available pet profiles.');
        }

        // Parse pet entries from data
        const pets = data.trim().split('\n').map(line => {
            const [index, owner_name, animal, breed, age, gender, compatibility_dogs, compatibility_cats, compatibility_children, comments, owner_email] = line.split(':');
            return { index,  owner_name, animal, breed, age, gender, compatibility_dogs, compatibility_cats, compatibility_children, comments, owner_email };
        });

        // Apply filters
        const filteredPets = pets.filter(pet => {
            return (
                (animal1 === 'doesn\'t matter' || pet.animal === animal1) &&
                (breed1 === 'doesn\'t matter' || pet.breed === breed1) &&
                (age1 === 'any' || pet.age === age1) &&
                (gender1 === 'any' || pet.gender === gender1) &&
                ((other_dogs && pet.compatibility_dogs === 'yes') || !other_dogs) &&
                ((other_cats && pet.compatibility_cats === 'yes') || !other_cats) &&
                ((small_children && pet.compatibility_children === 'yes') || !small_children)
            );
        });

        // Check if matching pets are found
        if (filteredPets.length > 0) {
            // Render EJS template for displaying matching pet profiles
            res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'PetFound', pets: filteredPets, layout: 'layout' });
        } else {
            // Render EJS template for displaying message when no matching pets are found
            res.render('layout', { title: 'Purrfect Adoption Centre', year: new Date().getFullYear(), page: 'NoPet', pets: [], layout: 'layout' });
        }
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is listening at port:${port}`);
});

