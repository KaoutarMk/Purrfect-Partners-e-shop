
function displayDateTime(){

    let currentDate = new Date();
    let hours = currentDate.getHours();
    let minutes = currentDate.getMinutes();
    let seconds = currentDate.getSeconds();
    let year = currentDate.getFullYear();
    let month = currentDate.getMonth() + 1;
    let day = currentDate.getDate();

    hours = (hours < 10) ? "0" + hours : hours;
    minutes = (minutes < 10) ? "0" + minutes : minutes;
    seconds = (seconds < 10) ? "0" + seconds : seconds;
    month = (month < 10) ? "0" + month : month;
    day = (day < 10) ? "0" + day : day;

    let currentDateTime = year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;

    document.getElementById("datetime").innerHTML = currentDateTime;
}
setInterval(displayDateTime, 1000);

function FindDogCatSubmit(event) {
    event.preventDefault();

    const animal = document.querySelector('input[name="animal1"]:checked');
    const breed = document.getElementById('breed1');
    const age = document.getElementById('age1');
    const gender = document.getElementById('gender1');
    const compatibility = document.querySelectorAll('input[name="compatibility1"]:checked');

    if (!animal || !breed.value || !age.value || !gender.value) {
        alert("Please fill in all fields before submitting.");
        return;
    } else {
        alert("Form submitted successfully!");
        document.getElementById("form").submit();
    }
}

document.addEventListener('DOMContentLoaded', function () {
    // Add an event listener to the form submit event
    document.getElementById('form').addEventListener('submit', FindDogCatSubmit);
});

            document.getElementById("loginForm").addEventListener("submit", function(event) {
            event.preventDefault();
            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;
            const urlParams = new URLSearchParams(window.location.search);
            const sourcePage = urlParams.get('source');
            fetch('/login?source=' + sourcePage, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
             },
              body: JSON.stringify({ username, password })
         })
            .then(response => {
             if (response.ok) {
                 return response.text();
                } else {
                    throw new Error('Invalid username or password');
                }
          })
         .then(data => {
                // Redirect to HaveaPet.html if login is successful
                window.location.href = 'HaveaPet.html';
         })
            .catch(error => {
              alert(error.message);
            }); 
            });


function havePetSubmit1(event) {
    event.preventDefault(); 

    var animal = document.querySelector('input[name="animal"]:checked');
    var breed = document.getElementById('breed').value.trim();
    var age = document.getElementById('age').value;
    var gender = document.getElementById('gender').value;
    var compatibilityDogs = document.querySelector('input[name="compatibility_dogs"]:checked');
    var compatibilityCats = document.querySelector('input[name="compatibility_cats"]:checked');
    var compatibilityChildren = document.querySelector('input[name="compatibility_children"]:checked');
    var comments = document.getElementById('comments').value.trim();
    var ownerName = document.getElementById('owner_name').value.trim();
    var ownerEmail = document.getElementById('owner_email').value.trim();
    
    if (!animal || !breed || !age || !gender || !compatibilityDogs || !compatibilityCats || !compatibilityChildren || !ownerName ) {
        alert('Please fill in all required fields.');
        return false;
    }
    
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(ownerEmail)) {
        alert('Please enter a valid email address.');
        return false;
    }
    alert("Form submitted successfully!");
    document.getElementById("form2").submit();
}



        function havePetSubmit2(event) {
        event.preventDefault();
        const form = document.getElementById('form2');
        const formData = new FormData(form);
        const petInfo = {};
        formData.forEach((value, key) => {
            petInfo[key] = value;
        });

        // Extract the username directly from the form
        const username = document.getElementById('owner_name').value;

        // Add the extracted username to the petInfo object
        petInfo['username'] = username;

        fetch('/submitPet', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(petInfo)
        })
        .then(response => {
            if (response.ok) {
                return response.text();
            } else {
                throw new Error('Failed to add pet information.');
            }
        })
        .then(data => {
            alert(data); // Display success message
            form.reset(); // Clear the form after successful submission
        })
        .catch(error => {
            alert(error.message); // Display error message
        });
    }


        function validateAndSubmit(event) {
            event.preventDefault(); // Prevent default form submission behavior
        
            // Call the first havePetSubmit function for validation
            if (!havePetSubmit1(event)) {
                return false; // Return false if validation fails
            }
        
            // Call the second havePetSubmit function for form submission
            havePetSubmit2(event);
        
            return false; // Prevent further form submission
        }